#include "ip_calc.h"

int main() {
    afficher_entete();
    traiter_requete();
    return 0;
}
