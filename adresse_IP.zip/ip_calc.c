#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ip_calc.h"

void afficher_entete() {
    printf("Content-Type:text/html\n\n");
    printf("<html><head><title>Informations Réseau IP</title></head><body>");
}

char *classe_ip(int octet1, int octet2, int octet3, int octet4) {
    static char classe[20];
    if(octet1 < 0 || octet1 > 255 || octet2 < 0 || octet2 > 255 || octet3 < 0 || octet3 > 255 || octet4 < 0 || octet4 > 255) {
        strcpy(classe, "IP Invalide");
    } else if(octet1 >= 0 && octet1 <= 127) {
        strcpy(classe, "Classe A");
    } else if(octet1 >= 128 && octet1 <= 191) {
        strcpy(classe, "Classe B");
    } else if(octet1 >= 192 && octet1 <= 223) {
        strcpy(classe, "Classe C");
    } else if(octet1 >= 224 && octet1 <= 239) {
        strcpy(classe, "Classe D");
    } else if(octet1 >= 240 && octet1 <= 255) {
        strcpy(classe, "Classe E");
    } else {
        strcpy(classe, "IP Invalide");
    }
    return classe;
}

char *masque_default(int octet1, int octet2, int octet3, int octet4) {
    static char masque[20];
    char *classe = classe_ip(octet1, octet2, octet3, octet4);
    if(strcmp(classe, "Classe A") == 0) {
        strcpy(masque, "255.0.0.0");
    } else if(strcmp(classe, "Classe B") == 0) {
        strcpy(masque, "255.255.0.0");
    } else if(strcmp(classe, "Classe C") == 0) {
        strcpy(masque, "255.255.255.0");
    } else {
        strcpy(masque, "Inconnu");
    }
    return masque;
}

void type_reseau(int octet1, int octet2, int octet3, int octet4) {
    char type[250];
    char *classe = classe_ip(octet1, octet2, octet3, octet4);
    if(strcmp(classe, "Classe A") == 0) {
        strcpy(type, "Réseau A");
    } else if(strcmp(classe, "Classe B") == 0) {
        strcpy(type, "Réseau B");
    } else if(strcmp(classe, "Classe C") == 0) {
        strcpy(type, "Réseau C");
    } else {
        strcpy(type, "Classe non prise en charge");
        printf("<p>%s</p>", type);
    }
}

void calculer_adresses(int octet1, int octet2, int octet3, int octet4, const char *masque, char *reseau, char *broadcast) {
    int masque_div[4];
    int ip_div[4] = {octet1, octet2, octet3, octet4};
    int reseau_div[4], broadcast_div[4];
    sscanf(masque, "%d.%d.%d.%d", &masque_div[0], &masque_div[1], &masque_div[2], &masque_div[3]);
    for(int i = 0; i < 4; i++)
        reseau_div[i] = ip_div[i] & masque_div[i];
    for(int i = 0; i < 4; i++)
        broadcast_div[i] = ip_div[i] | (~masque_div[i] & 255);
    sprintf(reseau, "%d.%d.%d.%d", reseau_div[0], reseau_div[1], reseau_div[2], reseau_div[3]);
    sprintf(broadcast, "%d.%d.%d.%d", broadcast_div[0], broadcast_div[1], broadcast_div[2], broadcast_div[3]);
}

void traiter_requete() {
    char *donnees = getenv("QUERY_STRING");
    if(donnees == NULL) {
        printf("<p>Erreur lors de l'analyse des données.</p>");
        printf("<button><a href=\"index.html\">Réessayer</a></button>");
        printf("</body></html>");
        exit(1);
    }
    char masque[250];
    char *classe;
    int octet1, octet2, octet3, octet4;
    char adresse_reseau[250];
    char adresse_diffusion[250];
    int resultat_lecture = sscanf(donnees, "ip=%d.%d.%d.%d&msr=%s", &octet1, &octet2, &octet3, &octet4, masque);
    if(resultat_lecture == 5) {
        char *masque_defaut = masque_default(octet1, octet2, octet3, octet4);
        if(strcmp(masque, masque_defaut) != 0) {
            printf("<p>Masque de sous-réseau inconnu</p>");
            printf("<button><a href=\"index.html\">Réessayer</a></button>");
            printf("</body></html>");
            exit(1);
        } else {
            classe = classe_ip(octet1, octet2, octet3, octet4);
            calculer_adresses(octet1, octet2, octet3, octet4, masque, adresse_reseau, adresse_diffusion);
            printf("<table border=\"1\">");
            printf("<tr><td><strong>IP</strong></td><td><strong>Masque</strong></td></tr>");
            printf("<tr><td>%d.%d.%d.%d</td><td>%s</td></tr>", octet1, octet2, octet3, octet4, masque);
            printf("</table>");
            printf("<table border=\"1\">");
            printf("<br><tr><td><strong>Type</strong></td><td><strong>Adresse</strong></td></tr><br>");
            printf("<br><tr><td>Adresse Réseau</td><td>%s</td></tr><br>", adresse_reseau);
            printf("<tr><td>Adresse de Diffusion</td><td>%s</td></tr>", adresse_diffusion);
            printf("</table>");
            printf("<p><strong></strong> %s</p>", classe);
            type_reseau(octet1, octet2, octet3, octet4);
        }
    } else {
        printf("<p>Adresse IP invalide</p>");
        printf("<button><a href=\"index.html\">Réessayer</a></button>");
    }
    printf("</body></html>");
}
