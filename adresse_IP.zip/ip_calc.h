#ifndef IP_CALC_H
#define IP_CALC_H

void afficher_entete();
void traiter_requete();
char *classe_ip(int octet1, int octet2, int octet3, int octet4);
char *masque_default(int octet1, int octet2, int octet3, int octet4);
void type_reseau(int octet1, int octet2, int octet3, int octet4);
void calculer_adresses(int octet1, int octet2, int octet3, int octet4, const char *masque, char *reseau, char *broadcast);

#endif
