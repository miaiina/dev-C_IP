#ifndef CIDR_H
#define CIDR_H

int bits_requis(int sous_reseaux);
unsigned int ip_to_int(const char *ip) ;
void int_to_ip(unsigned int val, char *ip);
unsigned int masque_sous_reseau(int longueur);
void afficher_reseau(unsigned int ip, unsigned int masque);
void diviser_reseau(unsigned int base, unsigned int masque, int nb_sous_reseaux);
void obtenir_donnees(char *ip, int *longueur, int *sous_reseaux) ;

#endif
