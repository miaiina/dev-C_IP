#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "cidr.h"

// Fonction pour déterminer le nombre de bits nécessaires pour le sous-réseautage
int bits_requis(int sous_reseaux) {
    int bits = 0;
    while (pow(2, bits) < sous_reseaux) {  // Utiliser pow(2, bits) au lieu de 1 << bits
        bits++;
    }
    return bits;
}

// Fonction pour convertir une adresse IP de chaîne à entier
unsigned int ip_to_int(const char *ip) {
    unsigned int val = 0;
    int octet;
    char tmp[16];
    strncpy(tmp, ip, sizeof(tmp));
    tmp[15] = '\0';
    char *part = strtok(tmp, ".");

    while (part != NULL) {
        octet = atoi(part);
        val = val * 256 + octet;  // Utiliser la multiplication pour déplacer les bits à gauche
        part = strtok(NULL, ".");
    }
    return val;
}

// Fonction pour convertir un entier IP en chaîne
void int_to_ip(unsigned int val, char *ip) {
    unsigned int octet1 = val / (256 * 256 * 256);           // 2^24
    unsigned int octet2 = (val / (256 * 256)) % 256;         // 2^16
    unsigned int octet3 = (val / 256) % 256;                 // 2^8
    unsigned int octet4 = val % 256;                         // 2^0

    sprintf(ip, "%d.%d.%d.%d", octet1, octet2, octet3, octet4);
}

// Fonction pour générer le masque de sous-réseau à partir de la notation CIDR
unsigned int masque_sous_reseau(int longueur) {
    return ~((unsigned int)pow(2, 32 - longueur) - 1); // Utiliser pow pour la puissance
}

// Fonction pour afficher les informations du réseau
void afficher_reseau(unsigned int ip, unsigned int masque) {
    unsigned int adresse_reseau = ip & masque;
    unsigned int adresse_diffusion = adresse_reseau | ~masque;
    char reseau[16], diffusion[16], masque_str[16];

    int_to_ip(adresse_reseau, reseau);
    int_to_ip(adresse_diffusion, diffusion);
    int_to_ip(masque, masque_str);

    printf("\nInfos Réseau:\n");
    printf("Adresse Réseau: %s\n", reseau);
    printf("Adresse Diffusion: %s\n", diffusion);
    printf("Masque de Sous-Réseau: %s\n", masque_str);
}

// Fonction pour diviser le réseau en sous-réseaux et afficher les détails
void diviser_reseau(unsigned int base, unsigned int masque, int nb_sous_reseaux) {
    int bits_sup = bits_requis(nb_sous_reseaux);
    int nouvelle_longueur = 32 - bits_sup;
    unsigned int nouveau_masque = masque_sous_reseau(nouvelle_longueur);
    unsigned int taille_sous_reseau = ~nouveau_masque + 1;

    printf("\nDivision en %d sous-réseaux:\n", nb_sous_reseaux);
    for (int i = 0; i < nb_sous_reseaux; i++) {
        unsigned int sous_reseau = base + (i * taille_sous_reseau);
        unsigned int diffusion = sous_reseau + taille_sous_reseau - 1;
        char sous_reseau_str[16], diffusion_str[16];

        int_to_ip(sous_reseau, sous_reseau_str);
        int_to_ip(diffusion, diffusion_str);

        printf("Sous-Réseau %d:\n", i + 1);
        printf("  Adresse Réseau: %s\n", sous_reseau_str);
        printf("  Adresse Diffusion: %s\n\n", diffusion_str);
    }
}

// Fonction pour obtenir les données de l'utilisateur
void obtenir_donnees(char *ip, int *longueur, int *sous_reseaux) {
    printf("Entrez l'adresse IP (ex: 192.168.43.1): ");
    scanf("%15s", ip);

    printf("Entrez la longueur du masque (ex: 26 pour /26): ");
    scanf("%d", longueur);

    printf("Entrez le nombre de sous-réseaux: ");
    scanf("%d", sous_reseaux);
}
