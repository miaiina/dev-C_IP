#include "cidr.h"

// Fonction principale
int main() {
    char ip[16];
    int longueur, sous_reseaux;

    // Obtenir les données de l'utilisateur
    obtenir_donnees(ip, &longueur, &sous_reseaux);

    // Convertir l'adresse IP en entier et générer le masque de sous-réseau
    unsigned int ip_entier = ip_to_int(ip);
    unsigned int masque = masque_sous_reseau(longueur);

    // Afficher les détails du réseau
    afficher_reseau(ip_entier, masque);

    // Diviser le réseau en sous-réseaux et afficher les détails
    diviser_reseau(ip_entier & masque, masque, sous_reseaux);

    return 0;
}
